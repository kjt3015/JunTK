<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>CSS</title>
		<style>
			.jb {
				width: 100px;
				height: 100px;
				margin: 60px auto;
				background-color: orange;
				transition: all ease 1s;
			}
			.jb:hover {
				transform: rotate( 45deg );
			}
		</style>
	</head>
	<body>
		<img class="jb" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdCNtyFPAMvxdQofHxLID6GWFOjQCmlD3Gab23VmaC7k_xEGyFLH5NVc9zkBXo9v3NkBo&usqp=CAU">
	</body>
</html>